import React from 'react';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions, View, Text, StyleSheet } from 'react-native';

const screenWidth = Dimensions.get('window').width;

interface TrendData {
  labels: string[];
  alcohol: number[];
  benceno: number[];
  co: number[];
  co2: number[];
  h2: number[];
  humo: number[];
  nh3: number[];
}

interface TrendChartProps {
  trendData: TrendData;
}

export default function TrendChart({ trendData }: TrendChartProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tendencia de Sensores</Text>
      <LineChart
        data={{
          labels: trendData.labels,
          datasets: [
            { data: trendData.alcohol, color: (opacity = 1) => `rgba(255, 0, 0, ${opacity})`, strokeWidth: 2 },
            { data: trendData.benceno, color: (opacity = 1) => `rgba(0, 0, 255, ${opacity})`, strokeWidth: 2 },
            { data: trendData.co, color: (opacity = 1) => `rgba(0, 255, 0, ${opacity})`, strokeWidth: 2 },
            { data: trendData.co2, color: (opacity = 1) => `rgba(255, 165, 0, ${opacity})`, strokeWidth: 2 },
            { data: trendData.h2, color: (opacity = 1) => `rgba(128, 0, 128, ${opacity})`, strokeWidth: 2 },
            { data: trendData.humo, color: (opacity = 1) => `rgba(75, 0, 130, ${opacity})`, strokeWidth: 2 },
            { data: trendData.nh3, color: (opacity = 1) => `rgba(255, 20, 147, ${opacity})`, strokeWidth: 2 },
          ],
          legend: ['Alcohol', 'Benceno', 'CO', 'CO2', 'H2', 'Humo', 'NH3'],
        }}
        width={screenWidth - 40}
        height={260}
        chartConfig={{
          backgroundColor: '#fff',
          backgroundGradientFrom: '#e0f7fa',
          backgroundGradientTo: '#80deea',
          decimalPlaces: 2,
          color: (opacity = 1) => `rgba(0, 127, 122, ${opacity})`,
          labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
          style: { borderRadius: 16 },
        }}
        bezier
        style={{
          marginVertical: 8,
          borderRadius: 16,
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
});